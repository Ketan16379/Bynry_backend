Here Are Some of the Screen Shots of the Appilcation

The Application mainly focused on the customer service request and support 

![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/18aa7c36-fece-4690-8331-130d6083bedf)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/1bbb97e7-de1c-49e6-9971-c2d4e24e0bd8)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/e857a266-04ca-4a42-a30d-2022c3bb3a26)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/cf823dd0-04d7-40ae-88f8-fa9ab8bc0aa8)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/d81cdec9-dee8-4cda-a715-efdb064033d9)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/3b8711d5-a26d-4d5a-aab5-cf79a37f7dbe)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/abc88b8e-6dfc-448b-8ea7-93e42e7a4a9f)

Updated Pages
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/b09976d9-1ef0-4d5d-a105-0c1d1d1efaaa)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/bb766230-4ccc-4d8a-b8bb-c24fb70ccc84)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/f4c937f7-1fbb-4a08-8cd6-7c2afff8c4ea)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/409c3e24-1517-4732-9572-3ad4ff3d8ff1)
![image](https://github.com/Abhimasali23/Bynry_Case_Stydy/assets/84769906/1ada45fd-6792-4fa5-9b46-7cdfc838e8a6)

